﻿namespace BestShop.Pages.Admin.Users
{
	public class UserInfo
	{
		public int id;

		public string firstName;

		public string lastName;

		public string email;

		public string phone;

		public string address;

		public string password;

		public string role;

		public string createdAt;
	}
}
