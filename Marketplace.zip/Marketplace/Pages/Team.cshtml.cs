using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BestShop.Pages
{
    public class TeamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
