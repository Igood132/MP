To jest opis naszego projektu BestShop Marketplace.

To projekt naszej grupy, który w teorii może przynosić zyski, jeśli będą dostępne towary, klienci oraz współpraca z firmami kurierskimi.

Odpowiedzi na pytania:

1) od strony biznesowej, do czego służy, jakie rozwiązania dostarcza
Projekt platformy marketplace jest niezbędny dla biznesu, aby zwiększyć zasięg sprzedaży, ułatwić kontakt z klientami
i poprawić efektywność operacyjną. Umożliwia firmom dotarcie do nowych grup odbiorców, automatyzuje zarządzanie
zamówieniami, płatnościami i dostawami, a także redukuje koszty marketingowe dzięki wbudowanym narzędziom promocyjnym
i możliwości pracy z opiniami klientów.

2) od strony technicznej: użyte technologie na frontendzie i backendzie
Frontend - html, css, js, bootstrap
Backend - C#(asp.net core) SQL

3) schemat bazy danych
DataBase.png

4) czy są płatności - Systemu płatności nie ma, zapłata następuje wyłącznie przy odbiorze towaru.

5) czy jest logowanie google/facebook - nie ma, tylko rejestracja na stronie.

6) screenshoty - mam video

7) jakie były problemy w implementacji i jak zostały rozwiązane
7.1) Jednym z największych wyzwań była integracja systemu płatności. Długo szukaliśmy odpowiedniego rozwiązania, ale ostatecznie
nie udało nam się go znaleźć. Niektóre systemy płatności wymagały początkowego depozytu, inne — rejestracji konta i podania naszych
danych osobowych w celu potwierdzenia tożsamości, czego nie chcieliśmy robić. Ostatecznie zdecydowaliśmy się zrezygnować z systemu
płatności i zamiast tego zaproponować alternatywę — "płatność przy odbiorze towaru".
7.2) Podczas tworzenia strony napotkaliśmy pewne trudności z wdrożeniem projektu. Problemem było właściwe uruchomienie strony,
aby działała płynnie i bez problemów. Vladyslav poprosił swojego brata o pomoc, który pomógł rozwiązać kwestię wdrożenia.
Do hostingu wybraliśmy Amazon Web Services (AWS), co pozwoliło nam pomyślnie uruchomić projekt i zapewnić jego stabilne działanie.


8) Video - Wideoprezentacja projektu
https://youtu.be/YXlUFbYPRSI